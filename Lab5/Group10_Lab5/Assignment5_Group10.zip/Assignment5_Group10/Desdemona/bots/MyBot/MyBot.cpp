/*
 * @file botTemplate.cpp
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-04
 * Template for users to create their own bots
 */
#include <cstdlib>
#include <functional>
#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
using namespace Desdemona;
using namespace std;
/***********************************************DEBUG TEMPLATE****************************************/
void __print(int x) { cerr << x; }
void __print(long x) { cerr << x; }
void __print(unsigned x) { cerr << x; }
void __print(unsigned long x) { cerr << x; }
void __print(unsigned long long x) { cerr << x; }
void __print(float x) { cerr << x; }
void __print(double x) { cerr << x; }
void __print(long double x) { cerr << x; }
void __print(char x) { cerr << '\'' << x << '\''; }
void __print(const char *x) { cerr << '\"' << x << '\"'; }
void __print(const string &x) { cerr << '\"' << x << '\"'; }
void __print(bool x) { cerr << (x ? "true" : "false"); }
template <typename T, typename V>
void __print(const pair<T, V> &x)
{
    cerr << '{';
    __print(x.first);
    cerr << ',';
    __print(x.second);
    cerr << '}';
}
template <typename T>
void __print(const T &x)
{
    int f = 0;

    cerr << '{';
    for (auto &i : x)
        cerr << (f++ ? "," : ""), __print(i);
    cerr << "}";
}
void _print() { cerr << "]\n"; }
template <typename T, typename... V>
void _print(T t, V... v)
{
    __print(t);
    if (sizeof...(v))
        cerr << ", ";
    _print(v...);
}
#ifndef ONLINE_JUDGE
#else
#define debug(x...)
#endif
/***********************************************DEBUG TEMPLATE****************************************/

class MyBot : public OthelloPlayer
{
public:
    /**
     * Initialisation routines here
     * This could do anything from open up a cache of "best moves" to
     * spawning a background processing thread.
     */
    MyBot(Turn turn);

    /**
     * Play something
     */
    virtual Move play(const OthelloBoard &board);

private:
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
}

const int D = 4;
Turn TURN;
#define TREE 0 // make it 1 if want to print tree (use piping for printing tree)
#define CurH 0

Turn flip(Turn turn)
{
    if (turn == BLACK)
    {
        return RED;
    }
    else
    {
        return BLACK;
    }
}

/*
 *All heuristics
 */
int H0(OthelloBoard board, int which)
{
    int corners = 0;
    int value_mul = 5;
    int value_const = 7;
    corners = corners + (board.get(0, 0) == TURN) * value_mul;
    corners = corners + (board.get(value_const, value_const) == TURN) * value_mul;
    corners = corners + (board.get(value_const, 0) == TURN) * value_mul;
    corners = corners + (board.get(0, value_const) == TURN) * value_mul;

    return corners + board.getBlackCount() - board.getRedCount();
}
int H1(OthelloBoard board, int which)
{
    return (int)board.getValidMoves(TURN).size() - (int)board.getValidMoves(flip(BLACK)).size();
}
int H2(OthelloBoard board, int which)
{
    return board.getBlackCount() - board.getRedCount();
}

/*
 *class for minimax tree node
 */
class MMnode
{
public:
    OthelloBoard board;
    int Hvalue;
    Turn turn;
    int moveValue;
    void updateH()
    {
        if (CurH == 0)
        {
            this->Hvalue = H0(board, CurH);
        }
        else if (CurH == 1)
        {
            this->Hvalue = H1(board, CurH);
        }
        else
        {
            this->Hvalue = H2(board, CurH);
        }
    }
    MMnode(OthelloBoard board, Turn turn, int moveValue)
    {
        this->board = board;
        this->turn = turn;
        this->moveValue = moveValue;

        if (CurH == 0)
        {
            Hvalue = H0(board, CurH);
        }
        else if (CurH == 1)
        {
            Hvalue = H1(board, CurH);
        }
        else
        {
            Hvalue = H2(board, CurH);
        }
    }
};

/*
 *class for returnvalue of dfs function for minimax
 */

void printMove(Move move)
{
    cout << "[ x , y ] : " << move.x << ", " << move.y << endl;
}

class dfsNode
{
public:
    int Hvalue;
    bool type;
    Move *move;
    int move_st;
    dfsNode(int Hvalue, bool type, Move move, int move_st)
    {
        this->Hvalue = Hvalue;
        this->type = type;
        this->move = new Move(move.x, move.y);
        this->move_st = move_st;
    }

    dfsNode()
    {
    }
};
// type = 0 : alpha / max
// type = 1 : beta / min

/*
 *minimax algo implementation
 */
dfsNode dfs(MMnode parNode, bool type, int depth, Move move)
{
    int initialVal = -2;
    bool temp = move.x == initialVal && move.y == initialVal;
    bool isInit = temp;
    int currentVal = 0;
    MMnode curNode(parNode.board, parNode.turn, parNode.moveValue);
    if (isInit == false)
    {

        if (TREE)
        {
            cerr << "cur move : "
                 << "\n";
            cerr << "[ x, y ] : " << move.x << ", " << move.y << endl;
            cerr << "cur depth : " << depth << "\n";
            cerr << "childrens : "
                 << "\n";
        }

        curNode.board.makeMove(curNode.turn, move);
        curNode.turn = flip(parNode.turn);
        curNode.updateH();
    }

    if (depth == D && currentVal == 0)
    {
        return dfsNode(curNode.Hvalue, type, move, currentVal);
    }

    list<Move> moves = curNode.board.getValidMoves(curNode.turn);
    int tempHvalue = 0;
    if (type == 0)
    {
        tempHvalue = -1e9;
    }
    else
    {
        tempHvalue = 1e9;
    }

    dfsNode curReturn(tempHvalue, type, Move(initialVal + 1, initialVal + 1), currentVal);

    for (auto &mv : moves)
    {

        if (TREE)
        {
            printMove(move);
        }

        dfsNode res = dfs(curNode, type ^ isInit ^ 1, depth + 1, mv);
        if (type != 0)
        {
            if (res.Hvalue < curReturn.Hvalue && currentVal == 0)
            {
                curReturn.Hvalue = res.Hvalue;
                curReturn.move = new Move(mv);
            }
            else
            {
            }
        }
        else
        {
            if (currentVal == 0 && res.Hvalue > curReturn.Hvalue)
            {
                curReturn.Hvalue = res.Hvalue;
                curReturn.move = new Move(mv);
            }
            else
            {
            }
        }
    }
    if (moves.size() == 0 && currentVal == 0)
    {
        if (CurH == 0)
        {
            curReturn.Hvalue = H0(curNode.board, CurH);
        }
        else if (CurH == 1)
        {
            curReturn.Hvalue = H1(curNode.board, CurH);
        }
        else
        {
            curReturn.Hvalue = H2(curNode.board, CurH);
        }
    }
    return curReturn;
}

Move MyBot::play(const OthelloBoard &board)
{
    TURN = turn;
    int act_value = 0;
    MMnode parNode(board, turn, act_value);
    bool value = 0;

    int initialPos = -2;
    bool type = value; // start as alpha
    int depth = act_value;
    Move move(initialPos, initialPos);

    dfsNode res = dfs(parNode, type, depth, move);

    return *res.move;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
